| Feature | Description |
| --- | --- |
| **Name** | `en_pipeline` |
| **Version** | `0.0.0` |
| **spaCy** | `>=3.7.3,<3.8.0` |
| **Default Pipeline** | `textcat` |
| **Components** | `textcat` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | n/a |
| **License** | n/a |
| **Author** | [n/a]() |

### Label Scheme

<details>

<summary>View label scheme (27 labels for 1 components)</summary>

| Component | Labels |
| --- | --- |
| **`textcat`** | `change_order`, `registration_problems`, `change_shipping_address`, `cancel_order`, `newsletter_subscription`, `check_payment_methods`, `complaint`, `track_refund`, `get_invoice`, `contact_customer_service`, `delete_account`, `edit_account`, `switch_account`, `track_order`, `review`, `check_invoice`, `delivery_options`, `get_refund`, `payment_issue`, `contact_human_agent`, `check_cancellation_fee`, `check_refund_policy`, `create_account`, `place_order`, `recover_password`, `set_up_shipping_address`, `delivery_period` |

</details>